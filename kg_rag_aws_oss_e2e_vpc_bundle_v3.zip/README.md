# KG + RAG — VPC-enabled (No-NAT) with Cognito Authorizer & OpenSearch (v3)

This package **removes NAT** and instead provisions **Interface VPC Endpoints** (AWS PrivateLink) for services your Lambdas call.
It also adds a **Cognito JWT Authorizer** on `/query` and creates a **VPC-based OpenSearch** domain with an **index-builder Lambda**.

## What’s included
- **VPC** (2 private subnets, 2 AZs). No Internet Gateway, no NAT.
- **VPC endpoints (Interface)**: `cognito-idp`, `logs`, `sts` (extend as needed).
- **VPC endpoint (Gateway)**: `s3` (private S3 path for bulk-load and artifacts).
- **Neptune** cluster + instance in private subnets.
- **OpenSearch** domain in the VPC; security group allows Lambda SG.
- **Lambdas** in VPC: `auth_login`, `query_handler`, `index_builder`.
- **API Gateway HTTP API** with **Cognito JWT authorizer** on `/query`.
- **S3 bucket** (random suffix) for artifacts.
- Helper **`start_loader.sh`** to upload N-Triples and kick Neptune bulk-load.
- Updated **web UI** flow: it passes the Cognito **ID token** as `Authorization: Bearer <idToken>` to `/query`.

## Deploy
```bash
cd terraform_vpc_no_nat
cp terraform.tfvars.example terraform.tfvars   # adjust region/project_prefix
terraform init
terraform apply -auto-approve

# Create a user
aws cognito-idp sign-up   --client-id $(terraform output -raw cognito_app_client_id)   --username demo@example.com --password 'DemoPassw0rd!'   --user-attributes Name=email,Value=demo@example.com
aws cognito-idp admin-confirm-sign-up   --user-pool-id $(terraform output -raw cognito_user_pool_id)   --username demo@example.com
```

## Build & deploy Lambdas (if you edit code)
```bash
../scripts/deploy_lambdas_v3.sh
cd terraform_vpc_no_nat && terraform apply -auto-approve
```

## Index documents (Step 8 end-to-end)
```bash
# Trigger index builder (indexes the sample RND-42 and MAN-9 snippets)
curl -X POST "$(terraform output -raw api_invoke_url)/index/build"
```

## Web UI config
Edit your UI (from earlier bundle) `step10_ui/web/config.js`:
```js
window.APP_CONFIG = {{
  apiBase: "<api_invoke_url>",
  cognito: {{ clientId: "<cognito_app_client_id>" }}
}};
```
The UI already sends `Authorization: Bearer <idToken>` for `/query` (updated).

Generated: 2025-08-31 17:52 UTC
