# Auto KG Demo (dbt + Neo4j/Neptune)

## Quick Start (dbt with DuckDB)
1) Install:
   pip install dbt-duckdb

2) In this folder, run:
   dbt deps
   DBT_PROFILES_DIR=. dbt seed
   DBT_PROFILES_DIR=. dbt run

This will create `target/auto_kg.duckdb` with schemas:
- seeds.* (from CSV seeds)
- gold.*  (models selecting from seeds)

## Neo4j Load
- Copy files in `scripts/neo4j/*.csv` and `scripts/neo4j/load_sample.cypher` to Neo4j `import` dir.
- Run `cypher-shell -u neo4j -p <password> -f load_sample.cypher`

## Neptune Load
- Upload `scripts/neptune/neptune_sample.nt` to S3 at the path you set in `bulk_loader_request.json`.
- Call the bulk loader API (example):
  aws neptune-data start-loader-job \
    --region us-east-1 \
    --endpoint https://YOUR-NEPTUNE-ENDPOINT:8182 \
    --payload file://scripts/neptune/bulk_loader_request.json

## Sample Query (Neo4j)
MATCH (m:VehicleModel {id:'M1'})<-[:BELONGS_TO]-(t:Trim)-[:HAS_FEATURE]->(:Feature {id:'F1'})
RETURN t.id, t.modelYear;

## Sample Query (SPARQL; Neptune)
PREFIX ex: <http://example.com/auto#>
SELECT ?trim WHERE {
  ?trim a ex:Trim ;
        ex:belongsTo <http://example.com/model/M1> ;
        ex:hasFeature <http://example.com/feature/F1> .
}
