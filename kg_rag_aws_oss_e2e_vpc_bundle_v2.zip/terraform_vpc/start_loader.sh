#!/usr/bin/env bash
set -euo pipefail
if [ $# -lt 1 ]; then
  echo "Usage: $0 <path-to-nt-file>"
  exit 1
fi
NT_FILE="$1"

REGION=$(terraform output -raw aws_region 2>/dev/null || echo "")
if [ -z "$REGION" ]; then
  echo "Set aws_region in terraform.tfvars; falling back to env AWS_REGION"
  REGION="${AWS_REGION:-us-east-1}"
fi

NEPTUNE_ENDPOINT=$(terraform output -raw neptune_endpoint)
ROLE_ARN=$(terraform output -raw neptune_loader_role_arn)
BUCKET=$(terraform output -raw s3_bucket)

KEY="neptune/$(basename "$NT_FILE")"
echo "Uploading $NT_FILE to s3://$BUCKET/$KEY"
aws s3 cp "$NT_FILE" "s3://$BUCKET/$KEY" --region "$REGION"

echo "Starting Neptune bulk loader..."
aws neptunedata start-loader-job   --region "$REGION"   --endpoint "https://$NEPTUNE_ENDPOINT:8182"   --payload "{
    \"source\": \"s3://$BUCKET/$KEY\",
    \"format\": \"ntriples\",
    \"iamRoleArn\": \"$ROLE_ARN\",
    \"region\": \"$REGION\",
    \"failOnError\": \"FALSE\",
    \"parallelism\": \"MEDIUM\",
    \"queueRequest\": \"TRUE\"
  }"
