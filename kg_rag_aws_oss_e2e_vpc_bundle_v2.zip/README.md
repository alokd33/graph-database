# KG + RAG — VPC-enabled Terraform (Neptune, Lambda in VPC)

This bundle **creates the VPC + Neptune + Lambda (VPC)** and wires everything end-to-end.
It is a superset of the previous bundle (Step0..Step10).

> ⚠️ Costs: NAT Gateway, Neptune instance, and public IPs incur hourly charges. Destroy when done.

## What it builds
- **VPC** with 2x public + 2x private subnets (2 AZs), IGW, **NAT Gateway** (for Lambda outbound).
- **Gateway VPC Endpoint for S3** (private S3 access for Lambdas / bulk loader data-path).
- **Neptune** cluster + single instance, subnet group, **SG allowing 8182 from Lambda SG**.
- **IAM Role for bulk loader** (AmazonS3ReadOnlyAccess) + association to Neptune cluster.
- **Lambda (auth_login, query_handler)** in **private subnets**, SG egress → NAT.
- **API Gateway HTTP API** exposing `/auth/login` and `/query`.
- **S3 bucket** for static site/artifacts.

## Quick start
```bash
cd terraform_vpc
cp terraform.tfvars.example terraform.tfvars
# Edit variables (region, project_prefix). S3 bucket will be auto-suffixed to be globally unique.
terraform init
terraform apply -auto-approve

# Create a demo user
aws cognito-idp sign-up   --client-id $(terraform output -raw cognito_app_client_id)   --username demo@example.com --password 'DemoPassw0rd!'   --user-attributes Name=email,Value=demo@example.com
aws cognito-idp admin-confirm-sign-up   --user-pool-id $(terraform output -raw cognito_user_pool_id)   --username demo@example.com

# Build & (re)deploy lambdas (if you edit code)
../scripts/deploy_lambdas.sh
cd terraform_vpc && terraform apply -auto-approve
```

## Load data to Neptune (bulk loader, from the other bundle)
```bash
# 1) Generate triples (from Step0..Step5 of the other bundle)
python ../kg_rag_aws_oss_e2e_bundle_v1/step5_rdf_mapping/map_to_rdf.py   --gold ../kg_rag_aws_oss_e2e_bundle_v1/step3_gold/gold_out   --out  ./output

# 2) Upload to S3 and start loader
./start_loader.sh  ./output/neptune_sample.nt
```

## Web UI
- API URL: `terraform output -raw api_invoke_url`
- Edit `kg_rag_aws_oss_e2e_bundle_v1/step10_ui/web/config.js` with that URL and the `cognito_app_client_id` output, then open `index.html` locally or host on S3/CloudFront.
