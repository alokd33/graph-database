# Step 3 — Gold (Conformed)
