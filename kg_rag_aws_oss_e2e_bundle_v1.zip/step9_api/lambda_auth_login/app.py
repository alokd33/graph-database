import json, os, boto3
USER_POOL_ID=os.environ['USER_POOL_ID']; CLIENT_ID=os.environ['CLIENT_ID']; REGION=os.environ['AWS_REGION']
cog=boto3.client('cognito-idp', region_name=REGION)
def handler(event, context):
  body=json.loads(event.get('body','{}')); u=body.get('username'); p=body.get('password')
  if not u or not p: return {'statusCode':400,'headers':{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'},'body':json.dumps({'error':'username/password required'})}
  try:
    resp=cog.initiate_auth(AuthFlow='USER_PASSWORD_AUTH',AuthParameters={'USERNAME':u,'PASSWORD':p},ClientId=CLIENT_ID)
    return {'statusCode':200,'headers':{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'},'body':json.dumps(resp['AuthenticationResult'])}
  except cog.exceptions.NotAuthorizedException:
    return {'statusCode':401,'headers':{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'},'body':json.dumps({'error':'invalid credentials'})}
  except Exception as e:
    return {'statusCode':500,'headers':{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'},'body':json.dumps({'error':str(e)})}
