import requests, botocore.session
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
def signed_post(url, data, region, service='neptune-db'):
  session = botocore.session.get_session()
  creds = session.get_credentials().get_frozen_credentials()
  req = AWSRequest(method='POST', url=url, data=data, headers={'Content-Type':'application/x-www-form-urlencoded'})
  SigV4Auth(creds, service, region).add_auth(req)
  s=requests.Session(); r=s.send(req.prepare()); r.raise_for_status(); return r
def sparql_select(endpoint, query, region, iam_auth=False):
  if iam_auth:
    r=signed_post(f"https://{endpoint}:8182/sparql", f"query={requests.utils.quote(query)}", region); return r.json()
  else:
    r=requests.post(f"https://{endpoint}:8182/sparql", data={'query':query}, headers={'Accept':'application/sparql-results+json'}); r.raise_for_status(); return r.json()
