import json, os
from utils import sparql_select
from sparql_queries import CQ1, CQ2
NEPTUNE=os.environ['NEPTUNE_ENDPOINT']; REGION=os.environ['AWS_REGION']; IAM=os.environ.get('NEPTUNE_IAM_AUTH','false').lower()=='true'
def handler(event, context):
  body=json.loads(event.get('body','{}')); q=body.get('question','')
  if 'falcon x' in q.lower() and '2023' in q and 'acc' in q.lower() and 'ca' in q.lower():
    t=sparql_select(NEPTUNE, CQ1, REGION, iam_auth=IAM); trims=[b['trim']['value'].split('/')[-1] for b in t['results']['bindings']]
    s=sparql_select(NEPTUNE, CQ2, REGION, iam_auth=IAM); ans={ b['trim']['value'].split('/')[-1]: int(b['units']['value']) for b in s['results']['bindings'] }
    return {'statusCode':200,'headers':{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'},'body':json.dumps({'answer':ans,'trims':trims,'evidence':[{'doc_id':'RND-42','snippet':'ACC tuning for Falcon X ...'}]})}
  return {'statusCode':200,'headers':{'Content-Type':'application/json','Access-Control-Allow-Origin':'*'},'body':json.dumps({'message':'Try demo: Which 2023 Falcon X trims have ACC and CA sales on 2023-03-15?'})}
