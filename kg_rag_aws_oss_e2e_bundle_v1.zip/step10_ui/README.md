# Step 10 — Web UI
Edit web/config.js with API base and Cognito ClientId.
