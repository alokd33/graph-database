import argparse, boto3, pathlib
p=argparse.ArgumentParser(); p.add_argument('--bucket',required=True); p.add_argument('--prefix',required=True); a=p.parse_args()
s3=boto3.client('s3'); root=pathlib.Path(__file__).resolve().parents[1]/'step0_data'
for fp in root.glob('*'):
    key=f"{a.prefix}{fp.name}"; s3.upload_file(str(fp), a.bucket, key); print("uploaded", key)
