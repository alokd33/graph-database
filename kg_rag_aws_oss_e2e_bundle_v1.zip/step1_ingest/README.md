# Step 1 — Ingest to S3 (Bronze)
Run upload and validate scripts.
