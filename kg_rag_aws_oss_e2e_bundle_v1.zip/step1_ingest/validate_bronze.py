import argparse, boto3
p=argparse.ArgumentParser(); p.add_argument('--bucket',required=True); p.add_argument('--prefix',required=True); a=p.parse_args()
s3=boto3.client('s3'); r=s3.list_objects_v2(Bucket=a.bucket, Prefix=a.prefix); keys=[o['Key'] for o in r.get('Contents',[])]
assert any(k.endswith('sales.csv') for k in keys); assert any(k.endswith('features.json') for k in keys); print("OK", keys)
