# Step 7 — Neptune Load
Use bulk loader or Workbench to load `neptune_sample.nt`.
