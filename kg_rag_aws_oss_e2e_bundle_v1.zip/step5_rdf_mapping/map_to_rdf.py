# See previous cell for full version; minimal here
import argparse, pandas as pd
from pathlib import Path
a=argparse.ArgumentParser(); a.add_argument('--gold', required=True); a.add_argument('--out', required=True); A=a.parse_args()
g=Path(A.gold); out=Path(A.out); out.mkdir(parents=True, exist_ok=True)
BASE="http://example.com"; NS="http://example.com/auto#"; U=lambda k,i: f"<{BASE}/{k}/{i}>"
lines=[]
for r in pd.read_csv(g/'dim_vehicle_model.csv').to_dict(orient='records'):
  lines += [f"{U('model',r['model_id'])} <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{NS}VehicleModel> .",
            f"{U('model',r['model_id'])} <{NS}modelCode> \"{r['model_code']}\" .",
            f"{U('model',r['model_id'])} <http://www.w3.org/2000/01/rdf-schema#label> \"{r['model_name']}\" ."]
for r in pd.read_csv(g/'dim_trim.csv').to_dict(orient='records'):
  lines += [f"{U('trim',r['trim_id'])} <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{NS}Trim> .",
            f"{U('trim',r['trim_id'])} <{NS}modelYear> \"{int(r['model_year'])}\"^^<http://www.w3.org/2001/XMLSchema#gYear> .",
            f"{U('trim',r['trim_id'])} <{NS}belongsTo> {U('model',r['model_id'])} ."]
lines.append(f"<http://example.com/feature/F1> <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{NS}Feature> .")
lines.append(f"<http://example.com/feature/F1> <{NS}featureCode> \"ACC\" .")
lines.append(f"<http://example.com/feature/F1> <http://www.w3.org/2004/02/skos/core#prefLabel> \"Adaptive Cruise Control\" .")
for r in pd.read_csv(g/'bridge_trim_feature.csv').to_dict(orient='records'):
  lines += [f"{U('trim',r['trim_id'])} <{NS}hasFeature> <http://example.com/feature/F1> ."]
for r in pd.read_csv(g/'dim_part.csv').to_dict(orient='records'):
  lines += [f"{U('part',r['part_id'])} <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{NS}Part> .",
            f"{U('part',r['part_id'])} <{NS}partNumber> \"{r['part_number']}\" .",
            f"{U('part',r['part_id'])} <http://www.w3.org/2000/01/rdf-schema#label> \"{r['part_name']}\" ."]
for r in pd.read_csv(g/'bridge_part_fitment.csv').to_dict(orient='records'):
  lines += [f"{U('part',r['part_id'])} <{NS}fits> {U('trim',r['trim_id'])} ."]
for r in pd.read_csv(g/'fact_sales.csv').to_dict(orient='records'):
  lines += [f"{U('sale',r['sale_id'])} <http://www.w3.org/1999/02/22-rdf-syntax-ns#type> <{NS}SaleRecord> .",
            f"{U('sale',r['sale_id'])} <{NS}forTrim> {U('trim',r['trim_id'])} .",
            f"{U('sale',r['sale_id'])} <{NS}soldIn> <http://example.com/market/{r['region_code']}> .",
            f"{U('sale',r['sale_id'])} <{NS}saleDate> \"{r['sale_date']}\"^^<http://www.w3.org/2001/XMLSchema#date> .",
            f"{U('sale',r['sale_id'])} <{NS}quantity> \"{int(r['quantity'])}\"^^<http://www.w3.org/2001/XMLSchema#integer> ."]
(out/'neptune_sample.nt').write_text("\n".join(lines))
print('Wrote', out/'neptune_sample.nt')
