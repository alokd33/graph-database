# Step 6 — SHACL Validation
Use pySHACL locally or in Glue.
