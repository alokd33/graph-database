from rdflib import Graph; from pyshacl import validate; import argparse, sys
p=argparse.ArgumentParser(); p.add_argument('--data',required=True); p.add_argument('--shapes',required=True); A=p.parse_args()
g=Graph(); g.parse(A.data, format='nt'); sh=Graph(); sh.parse(A.shapes, format='turtle')
conf, rgraph, rtext = validate(g, shacl_graph=sh, inference='rdfs', serialize_report_graph=True); print(rtext); sys.exit(0 if conf else 1)
