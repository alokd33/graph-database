#!/usr/bin/env bash
set -e
pushd ../step9_api/lambda_auth_login && zip -r function.zip app.py requirements.txt >/dev/null && popd
pushd ../step9_api/lambda_query && zip -r function.zip app.py requirements.txt sparql_queries.py utils.py >/dev/null && popd
echo 'Zipped. Run: cd ../terraform && terraform apply'
