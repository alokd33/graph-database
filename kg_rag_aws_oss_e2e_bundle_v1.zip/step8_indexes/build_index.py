print('Implement OpenSearch indexing if desired.')
