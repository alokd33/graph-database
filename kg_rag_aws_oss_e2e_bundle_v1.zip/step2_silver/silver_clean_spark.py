import argparse, json, pandas as pd
from pathlib import Path
a=argparse.ArgumentParser(); a.add_argument('--in',dest='inp',required=True); a.add_argument('--out',dest='out',required=True); A=a.parse_args()
inp=Path(A.inp); out=Path(A.out); out.mkdir(parents=True, exist_ok=True)
pd.read_csv(inp/'sales.csv').to_csv(out/'sales_clean.csv', index=False)
features=json.load(open(inp/'features.json'))
rows=[{'trim_id':k,'feature_code':v} for k,vals in features.items() for v in vals]
pd.DataFrame(rows).to_csv(out/'trim_features.csv', index=False)
pd.read_csv(inp/'parts.csv').to_csv(out/'parts_clean.csv', index=False)
open(out/'_SUCCESS','w').write('ok'); print('silver written', out)
