# Car KG Walkthrough — Loader Bundle (v2)

Files:
- PDF: Car_KG_End_to_End_Walkthrough_v2.pdf (one page)
- neo4j/: CSVs + load_and_queries.cypher
- neptune/: neptune_sample.nt + bulk_loader_request.json + queries.sparql

Neo4j:
1) Put CSVs + cypher into Neo4j import dir.
2) Run: cypher-shell -u neo4j -p <password> -f load_and_queries.cypher

Neptune:
1) Upload neptune_sample.nt to S3 at the path in bulk_loader_request.json.
2) aws neptune-data start-loader-job --region us-east-1 --endpoint https://YOUR-ENDPOINT:8182 --payload file://neptune/bulk_loader_request.json

Generated: 2025-08-31 04:46 UTC
